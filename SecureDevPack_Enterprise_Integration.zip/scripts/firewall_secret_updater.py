import requests
import secrets
import string
from secure_hash import hash_password

FIREWALL_API = "https://firewall-endpoint.local/api/user/update"

def generate_password(length=16):
    chars = string.ascii_letters + string.digits + string.punctuation
    return ''.join(secrets.choice(chars) for _ in range(length))

def update_firewall_user(user):
    pwd = generate_password()
    hashed = hash_password(pwd)

    payload = {
        "username": user,
        "password": pwd
    }
    headers = {"Authorization": "Bearer <admin-token>"}
    r = requests.post(FIREWALL_API, json=payload, headers=headers)
    print(f"Senha atualizada para {user}. Hash: {hashed}")