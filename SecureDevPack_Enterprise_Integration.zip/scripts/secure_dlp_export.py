from secure_encrypt import encrypt_file

encrypt_file("clientes_sensiveis.xlsx", "dlp_protected.xlsx", "chave-super-secreta")