from ldap3 import Server, Connection, ALL
from secure_hash import verify_password

def ldap_verify(user_dn, input_pwd, stored_hash):
    if verify_password(input_pwd, stored_hash):
        server = Server('ldap://localhost', get_info=ALL)
        conn = Connection(server, user=user_dn, password=input_pwd)
        if conn.bind():
            print("Usuário autenticado com sucesso.")
            conn.unbind()
        else:
            print("Falha na autenticação LDAP.")
    else:
        print("Senha inválida (verificação de hash falhou).")