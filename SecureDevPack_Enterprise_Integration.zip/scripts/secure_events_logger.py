import json
import logging
from datetime import datetime

def log_event(event_type, detail, username="unknown"):
    event = {
        "timestamp": datetime.utcnow().isoformat(),
        "event_type": event_type,
        "user": username,
        "detail": detail
    }
    print(json.dumps(event))